<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form input values
    $email = $_POST['email'];
    $password = $_POST['password'];
    $username = $_POST['username'];

    // Connect to the MySQL database
    $host = 'localhost';
    $dbname = 'res';
    $dbuser = 'root'; // Assuming no password
    $dbpass = '';

    $conn = new mysqli($host, $dbuser, $dbpass, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Insert form input values into the database
    $stmt = $conn->prepare("INSERT INTO customer (email, password, username) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $email, $password, $username);

    if ($stmt->execute()) {
        echo "Data inserted successfully";
    } else {
        echo "Error inserting data into the database";
    }

    $stmt->close();
    $conn->close();
}
?>
